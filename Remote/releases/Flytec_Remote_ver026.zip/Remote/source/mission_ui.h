#ifndef MISSION_UI_H
#define MISSION_UI_H
#include <lvgl.h>
static constexpr uint8_t MISSION_WAYPOINT_CAPACITY = 16;
void missionUI_open(lv_obj_t *returnScreen);
void missionUI_initStorage();
bool missionUI_getWaypoint(uint8_t index,float *lat,float *lon,bool *bait,bool *hook);
bool missionUI_getHome(float *lat,float *lon);
#endif
