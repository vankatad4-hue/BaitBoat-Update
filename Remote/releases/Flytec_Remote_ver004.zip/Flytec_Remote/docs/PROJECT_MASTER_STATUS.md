## Project archive versioning rule

- Every distributed project ZIP must use the filename format `Flytec_Remote_verXXX.zip`.
- The initial release in this naming scheme is `Flytec_Remote_ver001.zip`.
- Every modification to any project file that changes the project deliverable increments `XXX` by exactly 1 (for example: `ver001` → `ver002`).
- Never overwrite an earlier versioned ZIP. Keep each release as a separate archive so previous versions remain recoverable.
- The version number in the ZIP filename is the authoritative project release number; update this rule's examples or release notes only when needed, not the naming format.

# Flytec V080 bait boat and remote — master project record

**Last consolidated:** 2026-11-16  
**Purpose:** Carry forward the agreed hardware, UI, navigation, safety and implementation decisions between future development sessions. This file is the detailed project record; `README.md` is the quick-start and current-code index.

## 1. Overall project goal

Retrofit the existing Flytec V080 bait boat while retaining its hull, two 550 brushed motors, battery indicator and main power switch. Replace the original boat control electronics with a new central custom PCB using removable connectors. Retain the original Flytec remote enclosure but replace its internal electronics with a Waveshare ESP32 touchscreen controller.

The intended mission is: manually drive to a chosen fishing location, save it as a waypoint, select it later, navigate there autonomously, release bait and hook, then return home. The operator must also be able to take manual control while autopilot is active. The two agreed override behaviours are selectable: temporary manual override with autopilot resume, or switch fully to manual mode.

## 2. Boat-side hardware decisions and known measurements

| Item | Current project information |
|---|---|
| Hull | Existing Flytec V080 retained |
| Motors | Existing standard 550 brushed motors retained; 12 V design target |
| Battery | Reported 12 V, 3S4P Li-ion pack, 2500 mAh, BMS rated 20 A; verify pack label and actual wiring before final power design |
| Existing controls | Original boat electronics still installed and operational as of last inspection; final retrofit replaces the control system |
| Main switch / battery indicator | Retain existing parts |
| Bait/hook actuators | Solenoids desired; bait solenoid FW0630 009 DC12V; hook solenoids FW0630 001 DC12V |
| Boat PCB envelope | 77 × 79 × 14 mm measured usable area; approximately 30 mm from compartment floor to inside of lid |
| PCB mounting holes | Not measured yet |
| Motor current / stall current | Not measured yet; must measure before selecting MOSFETs, connectors, copper and protection |
| Solenoid coil current | Not measured yet; must measure before final driver and flyback design |
| ESP32 | User owns a 38-pin ESP32 development board; carrier-style mounting was preferred |
| Excluded item | DHT11 is not part of this project |

The user previously replaced one original motor MOSFET with a DMTH3002LK3-13 and reported similar/same-size MOSFETs used for motor and solenoid drivers. This is historical information, not a validated new-board component selection. Do not copy the old MOSFET choice without checking voltage, current, gate drive, thermal and transient requirements.

## 3. Boat navigation and sensors

- **Selected boat controller/GNSS board: Heltec Wireless Tracker V1.2**, using its ESP32-S3FN8 processor and integrated UC6580 GNSS. This replaces the planned generic 38-pin ESP32 carrier and separate HGLRC M100 PRO B101 GNSS module. Exact V1.2 pin map, GNSS power control, UART routing and antenna configuration must be verified before wiring.
- **Selected motion/heading sensor: GY-91-style MPU-9250 + BMP280 module.** MPU-9250 provides 3-axis accelerometer, gyroscope and magnetometer; it replaces the separate QMC5883L compass and MPU6050 proposal. BMP280 provides atmospheric pressure and temperature only, not underwater depth. Verify the exact breakout-board revision, chip markings, voltage and I²C address.
- The Heltec board also contains SX1262 LoRa, but the selected boat/remote radio remains external nRF24L01+ PA/LNA. Leave SX1262 unused.
- Mount and calibrate the MPU-9250 away from motors, solenoids, high-current wiring and steel; validate heading with propulsion off and running. No GPIO pin assignments or sensor drivers are approved/implemented yet.
- GPS telemetry should include latitude, longitude, fix type, satellites, horizontal accuracy, speed, heading, sequence/timestamp and integrity check.
- Compass work must include calibration, mounting-axis correction and magnetic interference checks with motors and power wiring active.
- **Selected radio:** matching nRF24L01+ PA/LNA modules on remote and boat at 2.4 GHz. Initial test data rate is 250 kbps. The 500 m mixed-environment range remains unverified. Exact module variant, antenna, channel, GPIO assignments, power rail and compliant EIRP remain to be selected/verified. This supersedes the earlier SX1278 433 MHz and SX1262 868 MHz LoRa proposals.
- If radio is lost during autopilot, the preferred boat-side behaviour is return home, subject to valid GNSS, valid compass, safe home point and boat-side watchdog/failsafe checks. This policy is not implemented in the current remote firmware.

## 4. Remote hardware and firmware target

- Original Flytec V080 remote enclosure retained; replace internal electronics.
- Preferred display/controller: Waveshare ESP32-S3-Touch-LCD-4.3 Standard, SKU 25948, 800 × 480, ST7262 RGB LCD, GT911 touch, CH422G I/O expander, 16 MB flash and 8 MB OPI PSRAM.
- Target framework: Arduino IDE with LVGL 9.6.0 (9.6.x patch releases only for this project baseline).
- The display board had not yet been purchased at the time of the latest project planning. Firmware has not been tested on the physical Waveshare board.
- User wants complete source files with explanatory comments, and prefers incremental steps with compile/test feedback between stages.
- Original display cavity dimensions: 110 × 67 × 7 mm. Candidate Waveshare display dimensions discussed: 106.8 × 67 × 8 mm; verify mechanical fit with the actual board, bezel and connectors.
- Remote battery idea: two 18650 1200 mAh cells in parallel (1S2P, approximately 2400 mAh) with USB-C charging. Waveshare documentation was noted as recommending a capacity below 2000 mAh for its battery connector; this pack exceeds that recommendation. Verify the board charger/protection design and battery arrangement before connecting. Do not parallel separate charger outputs.

### Waveshare board resource constraints

- RGB LCD: GPIO 5 DE, 3 VSYNC, 46 HSYNC, 7 PCLK; RGB data pins GPIO 1/2/42/41/40, 39/0/45/48/47/21, 14/38/18/17/10.
- GT911: GPIO4 IRQ, GPIO8 SDA, GPIO9 SCL; CH422G EXIO1 touch reset.
- CH422G EXIO2 backlight; EXIO4 TF-card chip select; EXIO5 USB/CAN selection.
- TF SPI: GPIO11 MOSI, GPIO12 SCK, GPIO13 MISO.
- GPIO8/9 are shared I²C. GPIO15/16 are multiplexed RS485/CAN. GPIO19/20 are USB D-/D+.
- Do not assign these occupied pins to external joystick ADC, radio, buttons or other functions.
- The present code uses CH422G for backlight ON/OFF only. Variable brightness is not implemented; PWM control needs verified board-level hardware support.

## 5. Remote UI decisions

- 4.3-inch display shows map and sonar simultaneously in an equal split while driving, in both manual and autopilot modes.
- Optional full-screen map or full-screen echogram with a return control is desired.
- Sonar presentation: advanced, full CHIRP-style echogram with fish arches drawn on this same 4.3-inch display. User rejected a hybrid sonar / second-screen arrangement.
- Navigation preferences: boat-up orientation; route and approach display both enabled; arrival radius previously set to 3 (unit not yet confirmed); map style should support both standard/street and satellite; home point visible.
- Manual controls: tank/steering motor control selectable; separate switching; waypoint naming.
- UI prototype work in LVGL Pro Editor used Bulgarian labels and a main screen with map/sonar panels and Manual/Autopilot/STOP controls. That XML prototype is separate from the Arduino firmware source in this archive. The C++ firmware UI currently uses English labels.

## 6. Remote Settings screen and virtual keyboard

Current source modules: `settings_ui.h/.cpp`; main screen opens Settings through the header button.

Implemented in source:
- Category navigation: Wi-Fi, Display, Controls, Sonar, Map, System.
- LVGL virtual keyboard for Wi-Fi SSID and password fields.
- Wi-Fi scan request, SSID/password entry and connection request.
- Wi-Fi credentials and preferences stored in ESP32 Preferences/NVS.
- Display backlight ON/OFF using CH422G EXIO2.
- Day/night preference and screen-timeout preference stored, but not yet applied as a full theme engine or automatic dimming feature.
- Sonar profile saved locally in NVS: depth range, gain, fish sensitivity, noise rejection, ping-rate preference, echogram scroll speed, palette, fish arches/symbols, fish alarm, shallow/deep alarms and their thresholds.

Limitations:
- Sonar controls are only local preferences. There is no selected CHIRP module control API or radio settings packet, so settings do not reach sonar hardware.
- Controls, Map and System categories remain explanatory placeholders; they are not fully functional settings pages.
- Brightness is ON/OFF only, not a variable slider.
- Wi-Fi is a remote convenience function; it is not the boat command/telemetry link.
- Wi-Fi password is stored in NVS. Production credential protection requires a suitable secure-storage design and ESP32 flash encryption configuration.

## 7. GPS, map and offline storage implementation status

### Current remote code

- `boat_state.h/.cpp`: shared boat state; starts STOP-latched and unconfirmed.
- `boat_telemetry.h/.cpp`: telemetry structure and state application. GPS accepted only with an active reported radio link, GPS connected flag, reported 3D fix, coordinate ranges valid and telemetry receipt age no more than 2 seconds. This is a fresh-fix check, not a complete navigation-readiness check; accuracy and compass validity still need separate safety gates.
- `boat_ui.cpp`: coordinate, fix, satellite, accuracy and heading display; marker hidden without a fresh valid fix. Map background is still a diagnostic grid, not geographic imagery.
- `map_projection.h/.cpp`: WGS84 ↔ Web-Mercator world-pixel conversion and heading-based viewport offset rotation. Zoom guard now rejects unsupported zoom values above 22.
- `display_port.cpp`: board init, LVGL display/touch adapter and optional SD mount. TF SPI uses GPIO11/12/13 and CH422G EXIO4 for physical CS; GPIO6 is passed as a dummy CS to Arduino SD API. This arrangement remains unverified on the physical board.
- `offline_map.h/.cpp`: manifest check and single raw RGB565 tile reader into PSRAM; validates zoom, XYZ tile bounds, style, file size and read length. No multi-tile cache or LVGL geographic renderer yet.

### Offline tile pack format

```text
/maps/manifest.txt                  # begins with FLYTEC_MAP1
/maps/street/<z>/<x>/<y>.rgb565
/maps/satellite/<z>/<x>/<y>.rgb565
```

Each tile is an uncompressed 256 × 256 RGB565 image, 131,072 bytes, no header, XYZ/Web-Mercator scheme. No map imagery is included in this firmware archive. Map area/lakes have deliberately not been assumed or selected. Use lawful offline map sources and retain required attribution/licensing; do not bulk-download from the public OSM tile server.

### Still to implement

- Actual LVGL geographic tile renderer and PSRAM tile cache.
- Non-blocking SD tile loading so storage reads do not stall LVGL.
- Boat-centred map viewport, boat-up rotation using calibrated compass heading, zoom and recenter controls.
- Street/satellite style selection and home/waypoint overlays.
- Offline map pack generation/import tool and lake coverage selection.
- Waypoint persistence and map rendering integration.

## 8. Current code architecture and files

- `Flytec_Remote.ino`: setup/loop and application wiring.
- `boat_state.*`: shared boat state.
- `boat_commands.*`: application-level STOP, mode, motor, bait and hook commands with a transport callback.
- `boat_radio.*`: nRF24L01+ PA/LNA placeholder; no packet transport is active.
- `boat_telemetry.*`: telemetry structure and GPS validity/freshness handling; no live packet decoder calls it yet.
- `boat_ui.*`: main screen, diagnostic map/sonar panels, controls and Settings entry point.
- `settings_ui.*`: remote Settings and virtual keyboard.
- `joystick.*`: four-axis normalisation, calibration, dead-zone, tank/steering layouts, selectable autopilot override and safety gates.
- `joystick_calibration_ui.*`: calibration UI.
- `display_port.*`: Waveshare board/LCD/touch/LVGL adapter and SD mount.
- `esp_panel_board_custom_conf.h`: project-specific Waveshare board configuration.
- `offline_map.*`: offline map manifest and RGB565 tile loader.
- `map_projection.*`: map projection mathematics.
- `docs/FIRST_BUILD_CHECKLIST.md`, `docs/GPS_AND_OFFLINE_MAP_PLAN.md`, `docs/OFFLINE_MAP_STORAGE.md`: bring-up and subsystem notes.

## 9. Safety and not-yet-implemented functions

- Remote starts with emergency STOP active and unconfirmed. Do not clear this state without validated boat telemetry acknowledgement.
- Radio module is non-operational: `boatRadio_begin()` returns false, send returns false and update receives nothing.
- Joystick hardware reader in `Flytec_Remote.ino` intentionally returns false; no physical ADC pins are assigned. Motor commands are inhibited until hardware readings and all four-axis calibration are valid, radio is connected and STOP state is confirmed.
- Joystick calibration is RAM-only; no persistent calibration storage yet.
- No real motor command can reach the boat through this remote baseline. Bait/hook command types exist at application level but no radio transport exists.
- No boat-side firmware, GPS UART parser, QMC5883L driver, radio protocol, telemetry decoder, sonar driver or autopilot controller is included in this remote ZIP.
- Boat-side watchdog, failsafe return-home, GPS/compass quality checks, authenticated packets, command acknowledgements and independent motor/solenoid interlocks are mandatory before operation.
- Never connect this unfinished remote firmware to powered motor or solenoid stages or operate the boat based on placeholder UI indications.

## 10. Latest review changes in this archive

- Reworked Wi-Fi scan and connection status handling to use LVGL timers rather than blocking waits, preserving UI responsiveness.
- Reuses the Settings screen and its keyboard instance when the Settings window is reopened; the Settings page is kept allocated for the lifetime of the app.
- Sonar slider preferences are persisted on release rather than every drag update, reducing unnecessary NVS writes.
- Settings screen is reused when reopened instead of allocating a fresh screen and keyboard each time.
- Display timeout label reflects the stored preference accurately and states that automatic dimming is not active.
- Web-Mercator projection functions reject zoom values above 22; offline tile reader rejects invalid style enum values.
- README and subsystem notes consolidated to remove obsolete statements that SD mounting had not yet been added.

## 11. Validation status of this revision

The map projection module can be compiled and unit-tested independently. Static source checks (brace balance, expected module references and archive inventory) are useful but do not prove an Arduino build. The complete project has **not** been compiled against the actual installed Arduino-ESP32 core, LVGL 9.6.0, `ESP32_Display_Panel`, `ESP32_IO_Expander` and exact Waveshare board package in this session. Wi-Fi scan/connect, CH422G SD chip-select arrangement, LCD flush timing, touch orientation and all physical controls require hardware testing.

Before any water test, complete a compile against the real dependency versions, test display/touch/SD with motors disconnected, validate radio and STOP acknowledgement, then test motor outputs with the hull restrained and propulsion disconnected from water. Solenoids must be tested separately with current-limited supplies and appropriate flyback suppression.


## 10. Radio decision update — 2026-11-16

The user selected nRF24L01+ PA/LNA modules at both ends (remote and boat). Initial testing should start at 250 kbps. The remote-side module is not yet wired or operational. See `docs/RADIO_LINK_DESIGN.md` for the shared design requirements. No pinout, RF channel, antenna, exact module supplier/model, application packet protocol or legal EIRP configuration has been finalized.


## Hardware selection update — ver003 (2026-11-16)

See `HARDWARE_SELECTION_VER003.md`. The boat controller/GNSS selection is Heltec Wireless Tracker V1.2; the selected motion/heading sensor is GY-91-style MPU-9250 + BMP280. This supersedes the HGLRC M100 PRO B101 + QMC5883L and separate MPU6050 proposal. nRF24L01+ PA/LNA remains selected. This is an architecture/documentation decision only; hardware has not been purchased or tested and boat-side firmware drivers remain unimplemented.


## Modular hardware update — ver004 (2026-11-17)

The user approved a central carrier PCB with removable cables for both remote and boat. The remote carrier is an interconnect hub for the separate nRF24L01+ PA/LNA radio, joystick modules, physical buttons and power module. The Waveshare ESP32-S3-Touch-LCD-4.3 Standard remains the main display/controller. See `CARRIER_PCB_CONNECTION_PLAN_VER004.md` for logical connector schedules, power-domain rules and pinout gates.

No external GPIO numbers are approved. Existing RGB LCD, GT911, CH422G, TF, USB and RS485/CAN resource use must be respected; check the exact board schematic and ADC/boot constraints before assignment. The proposed 1S2P 2400 mAh battery pack exceeds the previously noted Waveshare recommendation of below 2000 mAh for its battery connector; do not connect it to that connector without manufacturer confirmation. Use a separately engineered protected charger/power module and a verified board input.

This is a documentation-only update. Radio and joystick ADC remain stubs/placeholders; no operational remote-to-boat link is claimed.
