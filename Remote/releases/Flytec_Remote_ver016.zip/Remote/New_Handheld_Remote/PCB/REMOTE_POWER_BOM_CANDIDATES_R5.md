# SUPERSEDED by REMOTE_POWER_BOM_CANDIDATES_R6.md

# Remote Power + Controls BOM Candidate R5

**Candidate list only. Validate MPN/package/footprint/datasheet and ratings before procurement.**

| Ref | Candidate | Function / notes |
|---|---|---|
| J_PACK | keyed 2-pin ≥4A connector, TBD | 1S4P pack interface; polarity keyed |
| F_MAIN | Littelfuse 0458004.DR, 4A fast fuse candidate | Validate I²t, interrupt rating, derating, pack coordination |
| Q_REV | onsemi FDS6575 P-MOS SO-8 | Reverse-polarity protection candidate; D=PACK_FUSED, S=BAT_PROT; verify package/body diode |
| R_GATE | 100k | Gate-to-GND default bias |
| C_BAT | 100µF + 10µF + 100nF | BAT_PROT local decoupling candidates; review |
| J_WAVE_BAT | PH2.0 2P | Waveshare battery input; verify polarity/connector current |
| U_RADIO | TPS63070 | Dedicated RADIO_3V3 buck-boost |
| L_RADIO | Coilcraft XFL4020-152MEC 1.5µH | Candidate; saturation/current/footprint check |
| Radio capacitors | existing R4 values | Effective capacitance under bias, stability and ripple review |
| U_AXIS_ADC | ADS1115 @0x48 | Four joystick channels |
| U_MON_ADC | ADS1115 @0x49 | Battery, NTC and optional radio rail monitoring; address ADDR→3V3 |
| C_ADCx | 100nF each | Local supply bypass |
| R_AXIS | 1k each | Analog input series candidate |
| C_AXIS | 1µF each | Analog filter candidate; ~159Hz corner with 1k |
| U_BUTTONS | MCP23017 @0x20 | 16 button inputs; A0/A1/A2 low |
| U_RADIO_IO | MCP23017 @0x21 | CE/CSN/IRQ control candidate; A0 high, A1/A2 low |
| R_RESET | 10k per expander | RESET pull-up candidates |
| R_BAT_TOP/BOTTOM | 220k/68k, 1% | Pack sense divider to ADS1115@0x49 AIN0 |
| R_NTC_PULLUP | 10k, 1% | NTC divider from 3V3 |
| NTC_PACK | 10k B3950 candidate | Pack temperature sensor; exact curve/placement confirm |
| R_RADIO_DIV | 100k/100k 1% candidate | Optional RADIO_3V3 monitor to ADC2 AIN2; scales ~3.3V to ~1.65V |
| J_JOY_L/R | keyed 5P | 3V3/GND/X/Y/NC |
| J_RADIO | keyed 8P | GND/3V3/SCK/MOSI/MISO/CSN/CE/IRQ |
| J_NTC | 2P | NTC sense/GND |
| J_BUTTONS | TBD | 16 direct contacts; pinout and harness TBD |
| J_I2C | 4P | 3V3/GND/SDA/SCL, board-side access TBD |
| Testpoints | battery/rails/bus/analog | Access for bring-up |

Controller/display 5V is from Waveshare CS8501. E22 uses a dedicated external TPS61023 1S→5V branch; converter outputs are separate and never paralleled. Onboard board load spec 5V/450mA and battery boost/charge current documentation must be bench-confirmed for this use.


## LoRa backup radio addendum (R1)
| Ref | Candidate | Function / notes |
|---|---|---|
| U_LORA | EBYTE E22-900T22S-V2 (SX1262 UART; candidate only) | EU868-capable family; 22dBm maximum, 3.3V UART, verify regional SKU and configure legal output power |
| J_LORA | Module connector/footprint per exact module revision | 5V/GND/UART TX/RX/AUX/M0/M1; antenna uses matched 50Ω connector/coax |
| C_LORA | 100µF + 10µF + 100nF | Local decoupling candidates; test supply transient |
| ANT_LORA | 868MHz EU-band 50Ω antenna | RIGHT external antenna port; antenna gain, cable loss and EIRP/ERP compliance must be included |
| Boat U_LORA | Matching module on boat | Required for redundant link; remote-only installation is not functional redundancy |
| Boat ANT_LORA | 868MHz 50Ω antenna | Install separated from nRF antenna, motor wiring and metal obstructions |

E22 5V supply is a dedicated TPS61023 branch from BAT_PROT. CS8501 output is not shared with E22.


## E22 power correction R4
- U_E22 VCC: CS8501 5V rail (candidate branch; datasheet indicates ≥5V guarantees output power). UART and mode/status logic remain 3.3V. Reserve 150mA TX peak until actual 10dBm current measured.
- C_E22: 100µF+10µF+100nF local candidates. Scope rail under simultaneous display/backlight+nRF+LoRa TX.
- Separate 5V converter only if CS8501 margin fails; do not parallel boost outputs.


## E22 dedicated supply R5
| Ref | Candidate | Function / validation |
|---|---|---|
| U_LORA_BOOST | TPS61023 1S-to-5V boost (external converter) | Dedicated E22 VCC only; component values/layout per TI reference design; validate 150mA peak and rail transient/thermal |
| C_LORA_IN | 2×10µF + 100nF | Converter input; effective capacitance/DC-bias check |
| C_LORA_OUT | 2×22µF + 100µF + 100nF | Converter output/module local; ESR and stability verify |
| L_LORA | Reference-design inductor | Select from TPS61023 datasheet/application design; saturation/current rating verify |
| D_LORA | Reference-design diode, if topology requires | Select exact reference design |

CS8501 rail remains controller/display only. The LoRa converter is a separate battery branch and must not be connected in parallel to CS8501 output.
